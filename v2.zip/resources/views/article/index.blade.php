<x-app-layout>
    <div class="pagetitle">
        <h1>Articles</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item active">Articles</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <a href="{{ route('article.create') }}">
                    <button type="button" class="btn btn-primary">Create Article</button>
                </a>
                <br /><br>
                <div class="max-w-xl">
                    <!-- Table with stripped rows -->
                    <table class="table datatable">
                        <thead>
                            <tr>
                                <th>
                                    <b>T</b>itle
                                </th>
                                <th>URL Address</th>
                                <th>Date Joined</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($articles as $article)
                            <tr>
                                <td><a href="{{ route('article.show',$article->id)}}">{{ Str::limit($article->title, 70) }}</a></td>
                                <td><a target="_blank" href="{{ $article->article_url }}">Link</a></td>
                                <td>{{ $article->created_at->diffForHumans() }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <!-- End Table with stripped rows -->
                </div>
            </div>
        </div>
    </div>
</x-app-layout>