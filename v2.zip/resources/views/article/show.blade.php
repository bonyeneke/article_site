<x-app-layout>
    <div class="pagetitle">
        <h1>Articles</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('article.index') }}">Articles</a></li>
                <li class="breadcrumb-item active">View Article</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <section>
                        <header>
                            <h3 class="card-title">{{ $article->title }}</h3>
                        </header>

                        <div class="float-container">
                            <div class="float-child" style="display : inline-flex;">
                                <form method="post" action="{{ route('article.sendarticle', $article->id ) }}">
                                    @csrf
                                    <input value="1" name="sendto" type="hidden" />
                                    <button type="submit" class="btn btn-warning">Send for Review</button>
                                </form>
                            </div>
                            <div class="float-child" style="display : inline-flex;">
                                <form class="ml-3" method="post" action="{{ route('article.sendarticle', $article->id ) }}">
                                    @csrf
                                    <input value="2" name="sendto" type="hidden" />
                                    <button type="submit" class="btn btn-success">Send to Subscribers</button>

                                </form>
                            </div>
                            <a class="ml-3" href="{{ route('article.edit', $article->id) }}">
                                <button type="button" class="btn btn-secondary">Edit</button>
                            </a>
                            <div class="float-child" style="display : inline-flex;">
                                <form class="ml-3" method="post" action="{{ route('article.destroy', $article->id ) }}">
                                    @csrf
                                    @method('delete')
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </div>
                        </div>
                        <br>
                        <div class="p-2 flex justify-between">
                            <p><img src="{{ Storage::url($article->article_image) }}" alt="" /></p>
                            <p>
                            <h5>Description</h5>
                            </p>
                            <p>{{ $article->description }}<br>
                                Please read our latest Insight for more information on this guidance and how it may impact you and your business:
                            </p>
                            <hr>
                            <p>
                            <h5>Article URL</h5>
                            </p>

                            <p style="word-wrap: break-word;"><a target="_blank" href="{{ $article->article_url }}">{{ Str::limit($article->article_url,95) }}</a></p>
                            <hr>
                            <p>
                            <h5>Sent Status</h5>
                            @if($article->send == 0)
                            Not Sent
                            @else
                            Sent
                            @endif
                            </p>
                            <p>{{ $article->created_at->diffForHumans() }}</p>
                        </div>
                    </section>

                </div>
            </div>
        </div>
    </div>
</x-app-layout>