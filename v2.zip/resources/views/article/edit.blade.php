<x-app-layout>
    <div class="pagetitle">
        <h1>Articles</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('article.index') }}">Articles</a></li>
                <li class="breadcrumb-item active">Edit Article</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <div class="py-12">
        <div class="col-lg-9">
            <div class="card">
                <div class="card-body">
                    <section>
                        <header>
                            <h3 class="card-title">Edit Article</h3>
                        </header>

                        <form method="post" action="{{ route('article.update',$article->id) }}" enctype="multipart/form-data" class="mt-6 space-y-6">
                            @csrf
                            @method('patch')

                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label" for="title">Title</label>
                                <div class="col-sm-8">
                                    <x-text-input value="{{ $article->title }}" id="title" name="title" type="text" class="form-control" />
                                </div>
                                <x-input-error class="mt-2" :messages="$errors->get('title')" />
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label" for="title">Description</label>
                                <div class="col-sm-8">
                                    <textarea id="description" name="description" class="form-control">{{ $article->description }}</textarea>
                                </div>
                                <x-input-error class="mt-2" :messages="$errors->get('description')" />
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label" for="article_image">Article Image</label>
                                <div class="col-sm-8">
                                    <input type="file" class="form-control" id="article_image" name="article_image">
                                </div>
                                <x-input-error class="mt-2" :messages="$errors->get('article_image')" />
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label" for="article_url">Article URL</label>
                                <div class="col-sm-8">
                                    <textarea id="article_url" name="article_url" class="form-control">{{ $article->article_url }}</textarea>
                                </div>
                                <x-input-error class="mt-2" :messages="$errors->get('article_url')" />
                            </div>

                            <div class="flex items-center gap-4">
                                <button type="submit" class="btn btn-success">{{ __('Update Article') }}</button>
                            </div>
                        </form>
                    </section>

                </div>
            </div>
        </div>
    </div>
</x-app-layout>