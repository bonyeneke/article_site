<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
</head>

<body>
    <div class=WordSection1>

        <div style='margin:0!important;padding:0!important;height:100%!important;
width:100%!important'>

            <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%" style='width:100.0%;border-collapse:collapse;mso-yfti-tbllook:1184;mso-padding-alt:
 0in 0in 0in 0in'>
                <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
                    <td width="100%" valign=top style='width:100.0%;padding:0in 0in 0in 0in'>
                        <div align=center>
                            <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=660 style='width:495.0pt;background:white;border-collapse:collapse;mso-yfti-tbllook:
   1184;mso-padding-alt:0in 0in 0in 0in;min-width:660px' role=presentation>
                                <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
                                    <td style='padding:0in 0in 0in 0in'>
                                        <div id="x_col_01">
                                            <div style='display:table' id="x_blk_01">
                                                <div align=center>
                                                    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%" style='width:100.0%;background:white;border-collapse:collapse;
     mso-yfti-tbllook:1184;mso-padding-alt:0in 0in 0in 0in'>
                                                        <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
                                                            <td width="100%" valign=top style='width:100.0%;padding:22.5pt 22.5pt 22.5pt 22.5pt'>
                                                                <a href="http://www.grantthornton.com.ng" style="margin: 0;padding: 0;font-family: 'Avenir Next', &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;line-height: 1.65;color: #428BCA;text-decoration: none;"><img src="http://intranet.grantthornton.com.ng/public/img/gtlogo1.png" width="48%" border="0" alt="Grant Thornton Nigeria" /></a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </div>
                                            </div>
                                            <div align=center>
                                                <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%" style='width:100.0%;border-collapse:collapse;mso-yfti-tbllook:
     1184;mso-padding-alt:0in 0in 0in 0in'>
                                                    <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
                                                        <td valign=top style='background:#F2F0EE;padding:30.0pt 22.5pt 15.0pt 22.5pt'>
                                                            <div id="x_col_02">
                                                                <div style='display:table' id="x_blk_05">
                                                                    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%" style='width:100.0%;border-collapse:collapse;mso-yfti-tbllook:
       1184;mso-padding-alt:0in 0in 0in 0in' role=presentation>
                                                                        <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
                                                                            <td valign=top style='padding:0in 0in 0in 0in'>
                                                                                <div id="x_txt_05">
                                                                                    <p style='margin-bottom:15.0pt;line-height:18.0pt'>
                                                                                        <span style='font-size:10.5pt;font-family:"Arial",sans-serif;color:black'>
                                                                                            Dear {{ $name }},
                                                                                        </span><br /><br />
                                                                                        <span style='font-size:10.5pt;font-family:"Arial",sans-serif;color:black'>At Grant Thornton Nigeria, we're committed to providing you with the latest insights and updates in the dynamic world of accounting. As a subscriber to our articles, you're at the forefront of industry trends, best practices, and expert advice.</span>
                                                                                    </p>
                                                                                    <p style='margin-bottom:15.0pt;line-height:18.0pt'><span style='font-size:10.5pt;font-family:"Arial",sans-serif;color:black'>Whether you're a seasoned professional or just starting your journey in the field of accounting, our articles cover a wide range of topics tailored to meet your needs. From tax regulations and compliance updates to strategic financial planning and business advisory, we've got you covered.
                                                                                        </span>
                                                                                    </p>
                                                                                    <p style='margin-bottom:15.0pt;line-height:18.0pt'><span style='font-size:10.5pt;font-family:"Arial",sans-serif;color:black'>Your subscription not only keeps you informed but also empowers you to make well-informed decisions that drive success for your business or organization.</span></p>
                                                                                    <p style='margin-bottom:15.0pt;line-height:18.0pt'><span style='font-size:10.5pt;font-family:"Arial",sans-serif;color:black'>Thank you for choosing Grant Thornton Nigeria as your trusted source for accounting insights. We look forward to continuing this journey together and delivering valuable content straight to your inbox.</span></p>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </div>
                                                                <div style='display:table' id="x_blk_07">
                                                                    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%" style='width:100.0%;border-collapse:collapse;mso-yfti-tbllook:
       1184;mso-padding-alt:0in 0in 0in 0in' role=presentation>
                                                                        <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
                                                                            <td valign=top style='padding:0in 0in 0in 0in'>
                                                                                <div id="x_txt_07">
                                                                                    <h3 style='margin-top:0in'><span style='mso-fareast-font-family:"Times New Roman"'>Kind
                                                                                            regards,<br>
                                                                                            Grant Thornton</span></h3>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div style='display:table' id="x_blk_08">
                                                <p class=MsoNormal align=center style='text-align:center'><span style='mso-fareast-font-family:"Times New Roman";display:none;mso-hide:all'>

                                                    </span></p>
                                                <div align=center>
                                                    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%" style='width:100.0%;border-collapse:collapse;mso-yfti-tbllook:1184;mso-padding-alt:0in 0in 0in 0in' role=presentation>
                                                        <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
                                                            <td valign=top style='background:#4F2D7F;padding:30.0pt 22.5pt 22.5pt 22.5pt'>
                                                                <div id="x_col_03">
                                                                    <div style='display:table' id="x_blk_09">
                                                                        <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%" style='width:100.0%;background:#4F2D7F;border-collapse:
       collapse;mso-yfti-tbllook:1184;mso-padding-alt:0in 0in 0in 0in'>
                                                                            <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
                                                                                <td valign=top style='padding:0in 0in 15.0pt 0in'>
                                                                                    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%" style='width:100.0%;border-collapse:collapse;mso-yfti-tbllook:
         1184;mso-padding-alt:0in 0in 0in 0in'>
                                                                                        <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:
          yes'>
                                                                                            <td width="100%" style='width:100.0%;padding:0in 0in 0in 0in'>
                                                                                                <div id="x_txt_08">
                                                                                                    <p style='margin-bottom:7.5pt;line-height:18.0pt'><span style='font-family:"Arial",sans-serif;color:white'>&nbsp;<o:p>
                                                                                                            </o:p></span></p>
                                                                                                </div>
                                                                                            </td>
                                                                                            <td width=105 valign=top style='width:78.75pt;padding:0in 0in 0in 0in'>
                                                                                                <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=151 style='width:113.25pt;border-collapse:collapse;mso-yfti-tbllook:
           1184;mso-padding-alt:0in 0in 0in 0in' role=presentation>
                                                                                                    <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:
            yes'>
                                                                                                        <td width=26 valign=top style='width:19.5pt;padding:0in 0in 0in 15.0pt'>
                                                                                                            <div id="x_img_03">
                                                                                                                <p class=MsoNormal><span style='mso-fareast-font-family:"Times New Roman"'><a href="https://protect-eu.mimecast.com/s/vMnRCO9LslDVjCPHEJr?domain=marketing.grantthornton.com.ng" target="_blank"><span style='color:#3497FD;text-decoration:none;
            text-underline:none'><!--[if gte vml 1]><v:shape id="_x0000_i1031"
             type="#_x0000_t75" alt="LinkedIn"
             href="https://protect-eu.mimecast.com/s/vMnRCO9LslDVjCPHEJr?domain=marketing.grantthornton.com.ng"
             target="&quot;_blank&quot;" style='width:19.5pt;height:19.5pt'
             o:button="t">
             <v:imagedata src="Fw%20Share%20Options%20%20New%20employer%20PAYE%20requirements%20from%201%20January%202024_files/image006.png"
              o:href="cid:linkedin.png"/>
            </v:shape><![endif]-->
                                                                                                                                <![if !vml]><span style='mso-ignore:vglayout'><img border=0 width=26 height=26 src="Fw%20Share%20Options%20%20New%20employer%20PAYE%20requirements%20from%201%20January%202024_files/image006.png" style='outline:none;border-bottom-style:none;border-left-style:
            none;border-right-style:none;border-top-style:none;display:block;
            line-height:100%' alt=LinkedIn data-outlook-trace="F:1|T:1" v:shapes="_x0000_i1031"></span>
                                                                                                                                <![endif]>
                                                                                                                            </span></a>

                                                                                                                    </span></p>
                                                                                                            </div>
                                                                                                        </td>
                                                                                                    </tr>
                                                                                                </table>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                        </table>
                                                                    </div>
                                                                    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width="100%" style='width:100.0%;background:#4F2D7F;border-collapse:
       collapse;mso-yfti-tbllook:1184;mso-padding-alt:0in 0in 0in 0in'>
                                                                        <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
                                                                            <td valign=top style='padding:0in 0in 0in 0in'>
                                                                                <div id="x_txt_09">
                                                                                    <p style='margin-bottom:7.5pt;line-height:13.5pt'><span style='font-size:9.0pt;font-family:"Arial",sans-serif;color:white'>©
                                                                                            2024 Grant Thornton Nigeria is a member firm within Grant Thornton
                                                                                            International Ltd (Grant Thornton International). Grant
                                                                                            Thornton International and its member firms are not a worldwide
                                                                                            partnership. Grant Thornton International does not
                                                                                            provide services to clients. Services are delivered independently by the
                                                                                            member firms.<br>
                                                                                            <br>
                                                                                            Grant Thornton Nigeria · Victoria Island · Sabo Yaba · Abuja ·
                                                                                            Port-Harcourt<br>
                                                                                            <br>
                                                                                            View Grant Thornton's privacy statement <a href="https://protect-eu.mimecast.com/s/02QBCRBkUow91i0b82d?domain=marketing.grantthornton.com.ng" target="_blank"><span style='color:white'>here</span></a>.<br>
                                                                                            <br>
                                                                                            For information about Grant Thornton and its partners and services,
                                                                                            please visit <a href="https://protect-eu.mimecast.com/s/yFpTCLB0UV0xrsqZu-Q?domain=marketing.grantthornton.com.ng" target="_blank"><span style='color:white'>www.grantthornton.com.ng</span></a>.
                                                                                            The information contained in this e-mail is confidential and is
                                                                                            privileged. It is intended only for the addressee(s) stated above. If
                                                                                            you are not the intended addressee, any use, reliance, dissemination,
                                                                                            distribution, publication, or copying of any information contained in
                                                                                            this e-mail is strictly prohibited. If you have received this e-mail in
                                                                                            error, please immediately notify us by e-mail at <a href="mailto:info@ng.gt.com?subject=Enquiry"><span style='color:white'>info@ng.gt.com</span></a>
                                                                                            and delete this e-mail from your system</span></p>
                                                                                    <p style='margin-bottom:7.5pt;line-height:13.5pt'><span style='font-size:9.0pt;font-family:"Arial",sans-serif;color:white'><a href="https://protect-eu.mimecast.com/s/OGfjCWBpUZ17KIBoKub?domain=marketing.grantthornton.com.ng"><span style='color:white'>Preferences</span></a> | <a href="https://protect-eu.mimecast.com/s/L4nDCXVqfjlvRfxZjd0?domain=marketing.grantthornton.com.ng"><span style='color:white'>Unsubscribe</span></a>

                                                                                        </span></p>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </td>
                </tr>
            </table>

            <div id="x__t">

                <p class=MsoNormal style='background:gray'><span style='mso-fareast-font-family:
"Times New Roman";color:black;mso-color-alt:windowtext'><img border=0 width=1 height=1 id="_x0000_i1034" src="https://grantthorntonireland.vuture.net/email/b8f1c75a-be0e-4956-8dcc-85dbfffefcfd/analytics.gif" style='display:none'></span><span style='mso-fareast-font-family:"Times New Roman"'>

                    </span></p>

            </div>

        </div>

    </div>
</body>

</html>