<x-app-layout>
    <div class="pagetitle">
        <h1>Subscribers</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('subscriber.index') }}">Subscribers</a></li>
                <li class="breadcrumb-item active">Add a Subscriber</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <div class="py-12">
        <div class="col-lg-9">
            <div class="card">
                <div class="card-body">
                    <section>
                        <header>
                            <h3 class="card-title">Add a Subscriber</h3>
                        </header>

                        <form method="post" action="{{ route('subscriber.store') }}" enctype="multipart/form-data" class="mt-6 space-y-6">
                            @csrf

                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label" for="name">Subscriber Names</label>
                                <div class="col-sm-8">
                                    <x-text-input value="{{ old('name') }}" id="name" name="name" type="text" class="form-control" />
                                </div>
                                <x-input-error class="mt-2" :messages="$errors->get('name')" />
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label" for="name">Email Address</label>
                                <div class="col-sm-8">
                                    <x-text-input value="{{ old('email') }}" id="email" name="email" type="email" class="form-control" />
                                </div>
                                <x-input-error class="mt-2" :messages="$errors->get('email')" />
                            </div>

                            <div class="flex items-center gap-4">
                                <button type="submit" class="btn btn-primary">{{ __('Join Subscribers') }}</button>
                            </div>
                        </form>
                    </section>

                </div>
            </div>
        </div>
    </div>
</x-app-layout>