<x-app-layout>
    <div class="pagetitle">
        <h1>Subscribers</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item active">Subscribers</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <div class="py-12">
        <div class="max-w-xl">
            <section class="section">
                <div class="row">
                    <div class="col-lg-12">

                        <div class="card">
                            <div class="card-body"><br>
                                <p>
                                    <a class="p-2" href="{{ route('subscriber.create') }}">
                                        <button type="button" class="btn btn-outline-success">Add a Subscriber</button>
                                    </a>
                                </p>
                                <!-- Table with stripped rows -->
                                <table class="table datatable">
                                    <thead>
                                        <tr>
                                            <th>
                                                <b>N</b>ame
                                            </th>
                                            <th>Email</th>
                                            <th>Date Joined</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($subscribers as $subscriber)
                                        <tr>
                                            <td>{{ $subscriber->name }}</td>
                                            <td>{{ $subscriber->email }}</td>
                                            <td>{{ $subscriber->created_at->diffForHumans() }}</td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                                <!-- End Table with stripped rows -->

                            </div>
                        </div>

                    </div>
                </div>
            </section>
        </div>
    </div>
</x-app-layout>