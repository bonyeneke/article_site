<?php

use App\Http\Controllers\ArticleController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\SubscriberController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return redirect()->route('login');
});

Route::middleware('guest')->group(function () {
    Route::get('/subscriber/guestcreate', [SubscriberController::class, 'guest_create'])->name('subscriber.guestcreate');
    Route::post('/subscriber', [SubscriberController::class, 'guest_store'])->name('subscriber.guest_store');
});

Route::get('/dashboard', [DashboardController::class, 'index'])->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::middleware('auth')->group(function () {
    Route::resource('/article', ArticleController::class);
    Route::post('/article/{sendarticle}/sendarticle', [ArticleController::class, 'sendarticle'])->name('article.sendarticle');
});

Route::middleware('auth')->group(function () {
    Route::get('/subscriber', [SubscriberController::class, 'index'])->name('subscriber.index');
    Route::get('/subscriber/create', [SubscriberController::class, 'create'])->name('subscriber.create');
    Route::post('/subscriber', [SubscriberController::class, 'store'])->name('subscriber.store');
    Route::get('/subscriber/{subscriber}', [SubscriberController::class, 'show'])->name('subscriber.show');
    Route::delete('/subscriber', [SubscriberController::class, 'destroy'])->name('subscriber.destroy');
});

require __DIR__ . '/auth.php';
