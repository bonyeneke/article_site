<?php

namespace App\Http\Controllers;

use App\Models\Subscriber;
use App\Http\Requests\StoreSubscriberRequest;
use App\Http\Requests\UpdateSubscriberRequest;
use Illuminate\Support\Facades\Mail;

class SubscriberController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $subscribers = Subscriber::all();
        return view('subscriber.index', compact('subscribers'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('subscriber.create');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function guest_create()
    {
        return view('subscriber.guest_create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function guest_store(StoreSubscriberRequest $request)
    {
        $subscriber = Subscriber::create([
            'name' => $request->name,
            'email' => $request->email
        ]);

        return response()->redirectToRoute('subscriber.guestcreate');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreSubscriberRequest $request)
    {
        $subscriber = Subscriber::create([
            'name' => $request->name,
            'email' => $request->email
        ]);

        Mail::send(
            'emails.subscriber',
            array('name' => $subscriber->name),
            function ($message) use ($subscriber) {
                $message->from('nace2k2@gmail.com', 'Grant Thornton Communications');
                $message->to($subscriber->email, $subscriber->name)->subject("Welcome to Grant Thornton Nigeria's Accounting Insights Newsletter!");
            }
        );

        return response()->redirectToRoute('subscriber.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(Subscriber $subscriber)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    // public function edit(Subscriber $subscriber)
    // {
    //     //
    // }

    /**
     * Update the specified resource in storage.
     */
    // public function update(UpdateSubscriberRequest $request, Subscriber $subscriber)
    // {
    //     //
    // }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Subscriber $subscriber)
    {
        //
    }
}
