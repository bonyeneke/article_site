<?php

namespace App\Http\Controllers;

use App\Models\Article;
use App\Models\Subscriber;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $dbinfo['articles'] = Article::all()->count();
        $dbinfo['sentarticles'] = Article::where('sent', 1)->count();
        $dbinfo['subscribers'] = Subscriber::all()->count();
        $dbinfo['lastSentArticle'] = Article::where('sent', 1)->get()->last();
        return view('dashboard', compact('dbinfo'));
    }
}
