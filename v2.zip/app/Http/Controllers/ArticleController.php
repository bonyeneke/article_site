<?php

namespace App\Http\Controllers;

use App\Models\Article;
use App\Http\Requests\StoreArticleRequest;
use App\Http\Requests\UpdateArticleRequest;
use App\Models\Subscriber;
use App\Models\User;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Http\Request;

class ArticleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $articles = Article::all();
        return view('article.index', compact('articles'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('article.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreArticleRequest $request)
    {
        $path = $this->storeImage($request);
        $article = Article::create([
            'title' => $request->title,
            'description' => $request->description,
            'article_url' => $request->article_url,
            'article_image' => $path,
            'user_id' => auth()->id()
        ]);

        return response()->redirectToRoute('article.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(Article $article)
    {
        return view('article.show', compact('article'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Article $article)
    {
        return view('article.edit', compact('article'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateArticleRequest $request, Article $article)
    {
        $article->update([
            'title' => $request->title,
            'description' => $request->description,
            'article_url' => $request->article_url
        ]);

        if ($request->file('article_image')) {
            Storage::disk('public')->delete($article->article_image);
            $path = $this->storeImage($request);
            $article->update(['article_image' => $path]);
        }
        return view('article.show', compact('article'));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Article $article)
    {
        $article->delete();
        return redirect(route('article.index'));
    }

    protected function storeImage($request)
    {
        $ext = $request->file('article_image')->extension();
        $contents = file_get_contents($request->file('article_image'));
        $filename = Str::random(25);
        $path = "articles/$filename.$ext";
        Storage::disk('public')->put($path, $contents);
        return $path;
    }

    public function sendarticle($id, Request $request)
    {
        $article = Article::find($id);

        if ($request->sendto == "1") {
            $subscribers = User::all();
        } else {
            $subscribers = Subscriber::all();
            $article->sent = 1;
            $article->save();
        }

        foreach ($subscribers as $key => $subscriber) {
            Mail::send(
                'emails.article',
                array('name' => $subscriber->name, 'description' => $article->description, 'title' => $article->title, 'article_url' => $article->article_url, 'article_image' => $article->article_image),
                function ($message) use ($article, $subscriber) {
                    $message->from('nace2k2@gmail.com', 'Grant Thornton Communications');
                    $message->to($subscriber->email, $subscriber->name)->subject($article->title);
                }
            );
        }

        return redirect()->route('article.show', compact('article'));
    }
}
